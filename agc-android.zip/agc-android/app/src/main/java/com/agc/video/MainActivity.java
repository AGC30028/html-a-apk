package com.agc.video;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * AGC video autónomo.
 *
 * Dos navegadores internos (WebView):
 *   - ui:      la interfaz (assets/index.html). Tiene el puente "AGC" y ejecuta el agente.
 *   - browser: el navegador que el agente maneja. SIN puente (las webs no pueden tocar la app).
 *
 * El navegador del agente queda detrás de la interfaz, siempre a pantalla completa y visible
 * para Android, así que sigue renderizando y se pueden tomar capturas.
 */
public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final int REQ_FILE = 77;
    private static final String OVERRIDE_OPEN =
            "(function(){try{window.open=function(u){if(u)location.href=u;return null}}catch(e){}})()";

    private FrameLayout root;
    private WebView ui;
    private WebView browser;
    private Button backBtn;
    private WebViewAssetLoader loader;
    private File dlDir;
    private String browserUA = "";
    private boolean browserShown = false;
    private ValueCallback<Uri[]> filePathCb;
    private final ExecutorService io = Executors.newFixedThreadPool(3);
    private final Map<String, OutputStream> saves = new ConcurrentHashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dlDir = new File(getFilesDir(), "agcdl");
        //noinspection ResultOfMethodCallIgnored
        dlDir.mkdirs();
        boolean debuggable = (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        WebView.setWebContentsDebuggingEnabled(debuggable);

        loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/agcfiles/", new WebViewAssetLoader.InternalStoragePathHandler(this, dlDir))
                .build();

        DisplayMetrics dm = getResources().getDisplayMetrics();
        root = new FrameLayout(this);

        // Navegador del agente: tamaño fijo (no se achica cuando aparece el teclado)
        browser = new WebView(this);
        configure(browser, true);
        root.addView(browser, new FrameLayout.LayoutParams(dm.widthPixels, dm.heightPixels));
        browserUA = browser.getSettings().getUserAgentString();

        // Interfaz
        ui = new WebView(this);
        ui.setBackgroundColor(0xFF0B0E17);
        configure(ui, false);
        root.addView(ui, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        // Botón para volver a la interfaz cuando se está mirando el navegador del agente
        backBtn = new Button(this);
        backBtn.setText("◀ AGC");
        backBtn.setVisibility(View.GONE);
        backBtn.setOnClickListener(v -> showBrowser(false));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.END);
        bp.setMargins(0, (int) (40 * dm.density), (int) (8 * dm.density), 0);
        root.addView(backBtn, bp);

        setContentView(root);
        setupBrowserClients();
        setupUiClients();
        ui.addJavascriptInterface(new Bridge(), "AGC");
        ui.loadUrl("https://" + HOST + "/assets/index.html");

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    private void configure(WebView w, boolean isAgentBrowser) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        if (isAgentBrowser) {
            s.setSupportMultipleWindows(true);
            s.setJavaScriptCanOpenWindowsAutomatically(true);
            s.setSupportZoom(false);
            s.setBuiltInZoomControls(false);
            CookieManager.getInstance().setAcceptCookie(true);
            CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
        }
    }

    private void setupUiClients() {
        ui.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                openExternal(u.toString());
                return true;
            }
        });
        ui.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (filePathCb != null) filePathCb.onReceiveValue(null);
                filePathCb = cb;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    filePathCb = null;
                    return false;
                }
                return true;
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                request.deny();
            }
        });
    }

    private void setupBrowserClients() {
        browser.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String sc = request.getUrl().getScheme();
                // solo http/https/about dentro del navegador; intent:, market:, etc. se bloquean
                return !("http".equals(sc) || "https".equals(sc) || "about".equals(sc));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript(OVERRIDE_OPEN, null);
            }
        });
        browser.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                // ventanas emergentes: se cargan en el mismo navegador (una sola vista)
                final WebView tmp = new WebView(MainActivity.this);
                tmp.setWebViewClient(new WebViewClient() {
                    @Override
                    public void onPageStarted(WebView v, String url, Bitmap favicon) {
                        if (url != null && url.startsWith("http")) {
                            browser.loadUrl(url);
                            v.stopLoading();
                            v.post(v::destroy);
                        }
                    }
                });
                WebView.WebViewTransport t = (WebView.WebViewTransport) resultMsg.obj;
                t.setWebView(tmp);
                resultMsg.sendToTarget();
                return true;
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                request.deny();
            }

            @Override
            public boolean onJsAlert(WebView v, String url, String message, JsResult result) {
                result.confirm();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String message, JsResult result) {
                result.confirm();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView v, String url, String message, String defaultValue, JsPromptResult result) {
                result.confirm(defaultValue == null ? "" : defaultValue);
                return true;
            }

            @Override
            public boolean onJsBeforeUnload(WebView v, String url, String message, JsResult result) {
                result.confirm();
                return true;
            }
        });
        browser.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            final String name = URLUtil.guessFileName(url, contentDisposition, mimeType);
            io.execute(() -> {
                try {
                    JSONObject r = downloadFile(url, name, userAgent);
                    uiEvent("download", r.toString());
                } catch (Exception ignored) {
                }
            });
        });
    }

    /* ----------------------------- puente JS <-> Android ----------------------------- */
    private class Bridge {
        @JavascriptInterface
        public void req(final String id, final String method, final String argsJson) {
            runOnUiThread(() -> {
                try {
                    handle(id, method, new JSONObject(argsJson == null ? "{}" : argsJson));
                } catch (Throwable e) {
                    replyErr(id, String.valueOf(e));
                }
            });
        }
    }

    private void reply(final String id, final String rawJson) {
        runOnUiThread(() -> ui.evaluateJavascript(
                "window.__nat&&window.__nat.res(" + JSONObject.quote(id) + "," + JSONObject.quote(rawJson == null ? "null" : rawJson) + ")", null));
    }

    private void replyErr(String id, String msg) {
        reply(id, "{\"__err\":" + JSONObject.quote(msg) + "}");
    }

    private void uiEvent(final String name, final String rawJson) {
        runOnUiThread(() -> ui.evaluateJavascript(
                "window.__nat&&window.__nat.event(" + JSONObject.quote(name) + "," + JSONObject.quote(rawJson) + ")", null));
    }

    private void handle(final String id, String method, final JSONObject a) throws Exception {
        switch (method) {
            case "openBrowser":
                agentService(true);
                reply(id, "{\"ok\":true}");
                break;
            case "browserIdle":
                agentService(false);
                reply(id, "{\"ok\":true}");
                break;
            case "nav":
                browser.loadUrl(a.getString("url"));
                reply(id, "{\"ok\":true}");
                break;
            case "eval":
                browser.evaluateJavascript(a.getString("js"), value -> reply(id, value == null ? "null" : value));
                break;
            case "size":
                reply(id, "{\"w\":" + browser.getWidth() + ",\"h\":" + browser.getHeight() + "}");
                break;
            case "touch":
                tap(id, (float) a.getDouble("x"), (float) a.getDouble("y"));
                break;
            case "key":
                key(a.optString("key", ""), a.optInt("mods", 0));
                reply(id, "{\"ok\":true}");
                break;
            case "hideKeyboard": {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.hideSoftInputFromWindow(browser.getWindowToken(), 0);
                reply(id, "{\"ok\":true}");
                break;
            }
            case "shot":
                shot(id, a.optInt("quality", 45));
                break;
            case "canBack":
                reply(id, "{\"back\":" + browser.canGoBack() + "}");
                break;
            case "back":
                if (browser.canGoBack()) browser.goBack();
                reply(id, "{\"ok\":true}");
                break;
            case "http":
                io.execute(() -> reply(id, httpCall(a)));
                break;
            case "download":
                io.execute(() -> {
                    try {
                        reply(id, downloadFile(a.getString("url"), a.optString("name", "archivo"), browserUA).toString());
                    } catch (Exception e) {
                        replyErr(id, String.valueOf(e));
                    }
                });
                break;
            case "rm": {
                File f = new File(dlDir, safeName(a.optString("name", "")));
                //noinspection ResultOfMethodCallIgnored
                f.delete();
                reply(id, "{\"ok\":true}");
                break;
            }
            case "showBrowser":
                showBrowser(a.optBoolean("show", false));
                reply(id, "{\"ok\":true}");
                break;
            case "clearCookies":
                CookieManager.getInstance().removeAllCookies(null);
                CookieManager.getInstance().flush();
                WebStorage.getInstance().deleteAllData();
                browser.clearCache(true);
                reply(id, "{\"ok\":true}");
                break;
            case "saveBegin":
                io.execute(() -> {
                    try {
                        saves.put(a.getString("tid"), openSave(a.getString("name"), a.optString("mime", "application/octet-stream")));
                        reply(id, "{\"ok\":true}");
                    } catch (Exception e) {
                        replyErr(id, String.valueOf(e));
                    }
                });
                break;
            case "saveChunk":
                io.execute(() -> {
                    try {
                        OutputStream os = saves.get(a.getString("tid"));
                        if (os == null) throw new Exception("no hay descarga abierta");
                        os.write(Base64.decode(a.getString("b64"), Base64.DEFAULT));
                        reply(id, "{\"ok\":true}");
                    } catch (Exception e) {
                        replyErr(id, String.valueOf(e));
                    }
                });
                break;
            case "saveEnd":
                io.execute(() -> {
                    try {
                        OutputStream os = saves.remove(a.getString("tid"));
                        if (os != null) os.close();
                        reply(id, "{\"ok\":true}");
                    } catch (Exception e) {
                        replyErr(id, String.valueOf(e));
                    }
                });
                break;
            case "toast":
                Toast.makeText(this, a.optString("text", ""), Toast.LENGTH_SHORT).show();
                reply(id, "{\"ok\":true}");
                break;
            case "openUrl":
                openExternal(a.getString("url"));
                reply(id, "{\"ok\":true}");
                break;
            case "info":
                reply(id, "{\"sdk\":" + Build.VERSION.SDK_INT + ",\"app\":\"1.0\"}");
                break;
            default:
                replyErr(id, "método desconocido: " + method);
        }
    }

    /* ----------------------------- acciones sobre el navegador ----------------------------- */
    private void tap(final String id, final float x, final float y) {
        final long t = SystemClock.uptimeMillis();
        MotionEvent down = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0);
        down.setSource(InputDevice.SOURCE_TOUCHSCREEN);
        browser.dispatchTouchEvent(down);
        down.recycle();
        browser.postDelayed(() -> {
            MotionEvent up = MotionEvent.obtain(t, SystemClock.uptimeMillis(), MotionEvent.ACTION_UP, x, y, 0);
            up.setSource(InputDevice.SOURCE_TOUCHSCREEN);
            browser.dispatchTouchEvent(up);
            up.recycle();
            reply(id, "{\"ok\":true}");
        }, 60);
    }

    private int androidKey(String k) {
        if (k == null || k.isEmpty()) return 0;
        switch (k) {
            case "Enter": return KeyEvent.KEYCODE_ENTER;
            case "Backspace": return KeyEvent.KEYCODE_DEL;
            case "Delete": return KeyEvent.KEYCODE_FORWARD_DEL;
            case "Escape": return KeyEvent.KEYCODE_ESCAPE;
            case "Tab": return KeyEvent.KEYCODE_TAB;
            case "ArrowDown": return KeyEvent.KEYCODE_DPAD_DOWN;
            case "ArrowUp": return KeyEvent.KEYCODE_DPAD_UP;
            case "ArrowLeft": return KeyEvent.KEYCODE_DPAD_LEFT;
            case "ArrowRight": return KeyEvent.KEYCODE_DPAD_RIGHT;
            case "PageDown": return KeyEvent.KEYCODE_PAGE_DOWN;
            case "PageUp": return KeyEvent.KEYCODE_PAGE_UP;
            case "Home": return KeyEvent.KEYCODE_MOVE_HOME;
            case "End": return KeyEvent.KEYCODE_MOVE_END;
            case " ": return KeyEvent.KEYCODE_SPACE;
            default:
        }
        if (k.length() == 1) {
            char c = Character.toLowerCase(k.charAt(0));
            if (c >= 'a' && c <= 'z') return KeyEvent.KEYCODE_A + (c - 'a');
            if (c >= '0' && c <= '9') return KeyEvent.KEYCODE_0 + (c - '0');
        }
        return 0;
    }

    private void key(String k, int mods) {
        browser.requestFocus();
        long t = SystemClock.uptimeMillis();
        int meta = 0;
        if ((mods & 1) != 0) meta |= KeyEvent.META_ALT_ON;
        if ((mods & 2) != 0) meta |= KeyEvent.META_CTRL_ON;
        if ((mods & 4) != 0) meta |= KeyEvent.META_META_ON;
        if ((mods & 8) != 0) meta |= KeyEvent.META_SHIFT_ON;
        int code = androidKey(k);
        if (code != 0) {
            browser.dispatchKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0, meta));
            browser.dispatchKeyEvent(new KeyEvent(t, t + 20, KeyEvent.ACTION_UP, code, 0, meta));
        } else if (k != null && !k.isEmpty()) {
            browser.dispatchKeyEvent(new KeyEvent(t, k, 0, 0));
        }
    }

    private void shot(String id, int quality) {
        try {
            int w = browser.getWidth();
            int h = browser.getHeight();
            if (w <= 0 || h <= 0) throw new Exception("el navegador aún no tiene tamaño");
            Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            browser.draw(new Canvas(bmp));
            float sc = Math.min(1f, 720f / w);
            Bitmap out = sc < 1f ? Bitmap.createScaledBitmap(bmp, Math.round(w * sc), Math.round(h * sc), true) : bmp;
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            out.compress(Bitmap.CompressFormat.JPEG, Math.max(20, Math.min(90, quality)), bo);
            if (out != bmp) out.recycle();
            bmp.recycle();
            reply(id, "{\"b64\":\"" + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP) + "\"}");
        } catch (Throwable e) {
            replyErr(id, String.valueOf(e));
        }
    }

    private void showBrowser(boolean show) {
        browserShown = show;
        // La interfaz se desplaza fuera de pantalla (no se oculta) para que su JavaScript siga a pleno ritmo.
        ui.setTranslationX(show ? root.getWidth() : 0);
        backBtn.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) browser.requestFocus(); else ui.requestFocus();
        uiEvent("view", "{\"show\":" + show + "}");
    }

    private void agentService(boolean on) {
        Intent i = new Intent(this, AgentService.class);
        if (on) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            stopService(i);
        }
    }

    private void openExternal(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception ignored) {
        }
    }

    /* ----------------------------- red y archivos ----------------------------- */
    private static byte[] readAll(InputStream is) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
        is.close();
        return bo.toByteArray();
    }

    /** Petición HTTP sin restricciones CORS (para llamar a las APIs de IA). */
    private String httpCall(JSONObject a) {
        try {
            URL url = new URL(a.getString("url"));
            HttpURLConnection c = (HttpURLConnection) url.openConnection();
            c.setRequestMethod(a.optString("method", "GET"));
            c.setConnectTimeout(20000);
            c.setReadTimeout(a.optInt("timeout", 90000));
            c.setInstanceFollowRedirects(true);
            JSONObject h = a.optJSONObject("headers");
            if (h != null) {
                Iterator<String> it = h.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    c.setRequestProperty(k, h.getString(k));
                }
            }
            if (!a.isNull("body")) {
                c.setDoOutput(true);
                byte[] bb = a.getString("body").getBytes("UTF-8");
                try (OutputStream os = c.getOutputStream()) {
                    os.write(bb);
                }
            }
            int st = c.getResponseCode();
            InputStream is = st >= 400 ? c.getErrorStream() : c.getInputStream();
            byte[] data = is == null ? new byte[0] : readAll(is);
            JSONObject res = new JSONObject();
            res.put("status", st);
            res.put("b64", Base64.encodeToString(data, Base64.NO_WRAP));
            JSONObject hh = new JSONObject();
            String ct = c.getContentType();
            if (ct != null) hh.put("content-type", ct);
            res.put("headers", hh);
            return res.toString();
        } catch (Exception e) {
            return "{\"error\":" + JSONObject.quote(String.valueOf(e)) + "}";
        }
    }

    private static String safeName(String n) {
        String s = n == null ? "" : n.replaceAll("[^\\w.\\- ]+", "_");
        if (s.length() > 80) s = s.substring(s.length() - 80);
        if (s.isEmpty() || s.equals(".") || s.equals("..")) s = "archivo";
        return s;
    }

    /** Descarga con las cookies del navegador del agente (sesiones iniciadas). Máx. 400 MB. */
    private JSONObject downloadFile(String url, String name, String ua) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(20000);
        c.setReadTimeout(120000);
        c.setInstanceFollowRedirects(true);
        String ck = CookieManager.getInstance().getCookie(url);
        if (ck != null) c.setRequestProperty("Cookie", ck);
        c.setRequestProperty("User-Agent", ua != null && !ua.isEmpty() ? ua : browserUA);
        int st = c.getResponseCode();
        if (st >= 400) throw new Exception("el sitio respondió " + st);
        String safe = safeName(name);
        File f = new File(dlDir, safe);
        if (f.exists()) f = new File(dlDir, System.currentTimeMillis() + "-" + safe);
        long total = 0;
        try (InputStream is = c.getInputStream(); FileOutputStream os = new FileOutputStream(f)) {
            byte[] buf = new byte[32768];
            int n;
            while ((n = is.read(buf)) > 0) {
                total += n;
                if (total > 400L * 1024 * 1024) throw new Exception("archivo mayor a 400 MB");
                os.write(buf, 0, n);
            }
        }
        String ct = c.getContentType();
        JSONObject r = new JSONObject();
        r.put("name", f.getName());
        r.put("size", total);
        r.put("mime", ct == null ? "application/octet-stream" : ct.split(";")[0].trim());
        return r;
    }

    /** Guarda en Descargas/AGC (Android 10+) o en la carpeta de la app (versiones anteriores). */
    private OutputStream openSave(String name, String mime) throws Exception {
        String safe = safeName(name);
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Downloads.DISPLAY_NAME, safe);
            cv.put(MediaStore.Downloads.MIME_TYPE, mime);
            cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AGC");
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (uri == null) throw new Exception("no se pudo crear el archivo en Descargas");
            OutputStream os = getContentResolver().openOutputStream(uri);
            if (os == null) throw new Exception("no se pudo abrir el archivo en Descargas");
            return os;
        }
        File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (dir == null) dir = getFilesDir();
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        return new FileOutputStream(new File(dir, safe));
    }

    /* ----------------------------- ciclo de vida ----------------------------- */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE && filePathCb != null) {
            filePathCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            filePathCb = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (browserShown) {
            showBrowser(false);
        } else {
            // no cerrar la app por accidente mientras el agente trabaja
            moveTaskToBack(true);
        }
    }

    @Override
    protected void onDestroy() {
        agentService(false);
        io.shutdown();
        try {
            ui.destroy();
            browser.destroy();
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }
}
